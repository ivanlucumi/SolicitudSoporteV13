<?php

namespace SolicitudSoporte\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Illuminate\Support\Facades\Log;
use SolicitudSoporte\Models\Empleado;
use Carbon\Carbon;

class EmpleadosImports implements ToCollection, WithChunkReading
{
    public $rowsImported = 0;
    public $rowsSkipped = 0;
    public $rowsError = 0;

    public function collection(Collection $rows)
    {
        foreach ($rows as $index => $row) {

            try {

                Log::info('Fila leída', ['index' => $index]);

                // ❗ Evitar encabezados
                if (isset($row[0]) && $row[0] == 'CODIGO_SECCIONAL') {
                    continue;
                }

                // 🔹 Cédula principal (col 6)
                $cedula = isset($row[6]) ? preg_replace('/[^0-9]/', '', $row[6]) : null;

                // 🔹 Cédula comparación (col 51)
                $cedulaComparar = isset($row[51]) ? preg_replace('/[^0-9]/', '', $row[51]) : null;

                if (!$cedula) {
                    $this->rowsSkipped++;
                    Log::warning('Fila sin cédula', ['index' => $index]);
                    continue;
                }

                // 🔹 Validar coincidencia de cédulas
                $cedulasIguales = ($cedula && $cedulaComparar && $cedula === $cedulaComparar);

                if (!$cedulasIguales && $cedulaComparar) {
                    Log::warning('Cédulas no coinciden', [
                        'cedula_row6' => $cedula,
                        'cedula_row51' => $cedulaComparar,
                        'fila' => $index
                    ]);
                }

                // 🔹 Nombres y apellidos
                $nombre = strtoupper(trim(($row[14] ?? '') . ' ' . ($row[15] ?? '')));
                $apellido = strtoupper(trim(($row[12] ?? '') . ' ' . ($row[13] ?? '')));

                // 🔹 Fechas
                $fechaExpedicion = $this->parseFecha($row[5] ?? null);
                $fechaFin = $this->parseFecha($row[28] ?? null);
                $fechaRetiro = $this->parseFecha($row[19] ?? null);

                if (empty($fechaFin)) {
                    $fechaFin = $fechaRetiro;
                }

                // ===============================
                // 🔥 DEPENDENCIA (LÓGICA NUEVA)
                // ===============================
                if ($cedulasIguales) {
                    $codDependencia = !empty($row[45]) ? $row[45] : ($row[33] ?? null);
                    $dependencia    = !empty($row[46]) ? $row[46] : ($row[34] ?? null);
                } else {
                    $codDependencia = $row[33] ?? null;
                    $dependencia    = $row[34] ?? null;
                }

                // 🔹 Normalizar dependencia (quitar 127)
                if (!empty($codDependencia)) {
                    $codDependencia = trim((string) $codDependencia);

                    if (substr($codDependencia, 0, 3) === '127') {
                        $codDependencia = substr($codDependencia, 3);

                        Log::info('Prefijo 127 removido', [
                            'cedula' => $cedula,
                            'nuevo_cod_dependencia' => $codDependencia
                        ]);
                    }
                }

                // ===============================
                // 🔥 CARGO (LÓGICA NUEVA)
                // ===============================
                if ($cedulasIguales) {
                    $codCargo = !empty($row[42]) ? $row[42] : ($row[30] ?? null);
                    $cargo    = !empty($row[43]) ? $row[43] : ($row[31] ?? null);
                } else {
                    $codCargo = $row[30] ?? null;
                    $cargo    = $row[31] ?? null;
                }

                // 🔹 Guardar en BD
                Empleado::updateOrCreate(
                    ['cedulaE' => $cedula],
                    [
                        'nameE' => $nombre,
                        'lastnameE' => $apellido,
                        'clase_nombramiento' => strtoupper(trim($row[25] ?? '')),
                        'cod_cargo' => $codCargo,
                        'cargo_titular' => strtoupper(trim($cargo ?? '')),
                        'cod_dependencia' => $codDependencia,
                        'dependencia_titular' => strtoupper(trim($dependencia ?? '')),
                        'ciudad_ubicacion_laboral' => strtoupper(trim($row[39] ?? '')),
                        'cod_despacho' => $row[0] ?? null,
                        'fecha_expedicion' => $fechaExpedicion,
                        'fecha_retiro' => $fechaFin,
                        'estado' => 'A'
                    ]
                );

                $this->rowsImported++;

            } catch (\Throwable $e) {

                $this->rowsError++;

                Log::error('ERROR EN IMPORTACIÓN', [
                    'fila' => $index,
                    'data' => $row->toArray(),
                    'mensaje' => $e->getMessage(),
                    'linea' => $e->getLine()
                ]);
            }
        }

        // 🔹 Resumen final
        Log::info('RESUMEN IMPORTACIÓN', [
            'importados' => $this->rowsImported,
            'omitidos' => $this->rowsSkipped,
            'errores' => $this->rowsError
        ]);
    }

    public function chunkSize(): int
    {
        return 500;
    }

    // 🔥 FUNCIÓN PARA FECHAS
    private function parseFecha($value)
    {
        try {
            if (empty($value)) return null;

            if (is_numeric($value)) {
                return Carbon::instance(
                    \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($value)
                );
            }

            return Carbon::parse($value);

        } catch (\Exception $e) {

            Log::warning('Error parseando fecha', [
                'valor' => $value,
                'error' => $e->getMessage()
            ]);

            return null;
        }
    }
}