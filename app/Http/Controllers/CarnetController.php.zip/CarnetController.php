<?php

namespace SolicitudSoporte\Http\Controllers;

use Illuminate\Http\Request;
use SolicitudSoporte\Models\Empleado;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;

class CarnetController extends Controller
{
    
    // ─── GET /monitoreo/validador-carnets — Scanner PWA (Portería) ──────────
    public function validador()
    {
        return view('carnet.validador');
    }
    
    // ─── GET /monitoreo/validador-manual — Ingreso Manual ───────────────────
    public function validadorManual()
    {
        return view('carnet.validador_manual');
    }
    
    // ─── GET /carnet/consulta  —  Formulario de consulta ──────────────
    public function form()
    {
        return view('carnet.consulta_carnet');
    }
    
    public function redireccion(){
        return redirect()->route('carnet.consulta');
    }

    // ─── GET /mi-carnet — Vista local (PWA) ─────────────────────────────────
    public function miCarnet()
    {
        // Esta vista se renderiza por JS con los datos de localStorage.
        return view('carnet.mi_carnet');
    }

    // ─── POST /carnet/consultar  —  Procesa el formulario y muestra el carnet ─
    public function consultarCarnet(Request $request)
    {
        $request->validate([
            'cedula'           => 'required|string|max:15',
            'fecha_expedicion' => 'required|date|before_or_equal:today',
        ], [
            'cedula.required'            => 'El número de cédula es obligatorio.',
            'cedula.max'                 => 'La cédula no puede tener más de 15 caracteres.',
            'fecha_expedicion.required'  => 'La fecha de expedición es obligatoria.',
            'fecha_expedicion.date'      => 'La fecha de expedición no es válida.',
            'fecha_expedicion.before_or_equal' => 'La fecha de expedición no puede ser futura.',
        ]);

        $cedula           = preg_replace('/\D/', '', $request->cedula);
        $fechaExpedicion  = Carbon::parse($request->fecha_expedicion)->format('Y-m-d');

        $empleado = Empleado::where('cedulaE', $cedula)
                            ->where('fecha_expedicion', $fechaExpedicion)
                            ->first();

        if (! $empleado) {
            return redirect()
                ->route('carnet.consulta')
                ->with('error', 'No se encontró ningún empleado con la cédula y fecha de expedición ingresadas. Verifique los datos e inténtelo de nuevo.');
        }

        if (empty($empleado->carnet_token)) {
            $empleado->carnet_token = \Illuminate\Support\Str::uuid()->toString();
            $empleado->save();
        }

        return redirect()->route('carnet.public', ['token' => $empleado->carnet_token]);
    }

    // ─── GET /carnet/ver/{token}  —  Vista Blade (acceso directo público) ───────────────
    public function showPublic(string $token)
    {
        
        $empleado = Empleado::where('carnet_token', $token)->firstOrFail();
        //dd($empleado);
        return view('carnet.carnet_resultado', compact('empleado'));
    }

    // ─── POST /api/carnet/revocar ───────────────────────────────────────────
    public function revocar(Request $request): JsonResponse
    {
        $request->validate(['cedula' => 'required|string']);
        $cedula = preg_replace('/\D/', '', $request->cedula);
        
        $empleado = Empleado::where('cedulaE', $cedula)->first();
        if ($empleado) {
            $empleado->carnet_token = null;
            $empleado->save();
        }
        
        return response()->json(['success' => true]);
    }

    // ─── GET /api/carnet/validar?cedula=XXX ──────────────────────────────────
    public function validar(Request $request): JsonResponse
    {
        $request->validate(['cedula' => 'required|string|max:20']);

        $empleado = Empleado::where('cedulaE', $request->cedula)->first();

        if (! $empleado) {
            return response()->json([
                'encontrado' => false,
                'activo'     => false,
                'mensaje'    => 'Empleado no encontrado en el sistema',
            ], 404);
        }

        return response()->json([
            'encontrado' => true,
            'activo'     => $empleado->estaVigente(),
            'nombre'     => $empleado->nameE . ' ' . $empleado->lastnameE,
            'cargo'      => $empleado->cargo_titular,
            'cedula'     => $empleado->cedulaE,
            'vigencia'   => $empleado->vigencia_formateada,
            'sede'       => $empleado->ciudad_ubicacion_laboral,
            'observacion'=> $empleado->observacion,
            'mensaje'    => $empleado->estaVigente()
                             ? 'Funcionario Cuenta con CArnet Activo'
                             : 'Funcionario no cuenta con Carnet Activo, Contactar a Recursos Humanos',
        ]);
    }

    // ─── PATCH /api/carnet/{cedula}/estado ────────────────────────────────────
    public function actualizarEstado(Request $request, string $cedula): JsonResponse
    {
        $request->validate([
            'estado' => 'required|in:ACTIVE,INACTIVE,EXPIRED'
        ]);

        $empleado = Empleado::where('cedulaE', $cedula)->firstOrFail();
        $empleado->update(['activo' => $request->estado === 'ACTIVE']);

        return response()->json([
            'success' => true,
            'cedula'  => $cedula,
            'estado'  => $request->estado,
        ]);
    }
    // ─── GET /api/carnet/token/{token} ────────────────────────────────────
    public function getByToken(string $token): JsonResponse
    {
        $empleado = Empleado::where('carnet_token', $token)->first();

        if (! $empleado) {
            return response()->json(['error' => 'not_found'], 404);
        }

        return response()->json([
            'nombre'     => strtoupper($empleado->nameE) . ' ' . strtoupper($empleado->lastnameE),
            'iniciales'  => substr($empleado->nameE, 0, 1) . substr($empleado->lastnameE, 0, 1),
            'cedula'     => $empleado->cedulaE,
            'cargo'      => strtoupper($empleado->cargo_titular ?? $empleado->clase_nombramiento ?? 'EMPLEADO JUDICIAL'),
            'foto'       => $empleado->foto ?? 'https://www.disajcali.gov.co/img/carnet/prueba_carnet.jpg',
            'observacion'=> $empleado->observacion,
            'esActivo'   => $empleado->estaActivo()
        ]);
    }
}
