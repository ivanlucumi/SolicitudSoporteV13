$(document).ready(function() {
    
    toastr.options = {
        "closeButton": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };

    function searchUnified() {
        var searchValue = $('#unifiedSearch').val().trim();
        console.log("Starting search for:", searchValue);
        
        if (searchValue === "") {
            toastr.info('Por favor ingrese una cédula o placa');
            return;
        }

        var form = $('#form-consulta-placa-ingreso');
        if (form.length === 0) {
            console.error("Form #form-consulta-placa-ingreso not found!");
            toastr.error('Error interno: Formulario de consulta no encontrado');
            return;
        }

        var action = form.attr('action');
        if (!action) {
            console.error("Form action is empty!");
            toastr.error('Error interno: Ruta de consulta no definida');
            return;
        }

        var url = action.replace(':CEDULA_ID', searchValue);
        console.log("Request URL:", url);
        
        $.get(url, function(result) {
            console.log("Unified Search Result:", result);

            if (!result || result.length === 0 || (typeof result === 'object' && Object.keys(result).length === 0) || !result[0]) {
                Swal.fire({
                    title: "NO AUTORIZADO",
                    text: "No se encontró ningún vehículo o persona autorizada con la placa/cédula: " + searchValue,
                    icon: "error",
                    confirmButtonText: 'Aceptar',
                    confirmButtonColor: '#3085d6'
                });
                
                // Refrescar enfoque
                setTimeout(function() {
                    var search = document.getElementById('unifiedSearch');
                    if (search) { search.focus(); search.value = ''; }
                }, 1500);
                return;
            }

            // Módulo de restricciones
            if (result && result[0] && result[0].impedimento === "rest") {
                Swal.fire({
                    title: "INGRESO RESTRINGIDO", 
                    text: "El funcionario " + result[0].nombre + " tiene restricción: " + result[0].Restriccion, 
                    icon: "warning"
                });
                return;
            }

            // Caso Multi-Vehículo (2 o más opciones)
            if (result.length > 1) {
                fillModalMulti(result);
            } else {
                fillModalSingle(result[0]);
            }
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.error("AJAX Error:", textStatus, errorThrown);
            toastr.error('Error al consultar los datos: ' + textStatus);
        });
    }

    function fillModalSingle(data) {
        $('#id').val(data.id_parq);
        $('#identificacion').val(data.cedula);
        $('#nombre').val(data.nombre);
        $('#despacho').val(data.juzgado);
        $('#placa').val(data.placa);
        $('#tipo').val(data.tipo_vehiculo);

        // Mostrar empresa si existe (Temporales)
        if (data.empresa) {
            $('#empresa_modal').val(data.empresa);
            $('#div_empresa').show();
        } else {
            $('#div_empresa').hide();
        }
        $('#caract').val(data.descripcion_vehiculo);
        $('#estado_vehiculo').val(data.ocupado);
        $('#ubicacion_detalle').val(data.ubicacion_detalle);
        
        // Lógica de Portería
        if (data.permitido_porteria) {
            $('#advertencia_porteria_div').hide();
            $('#BotonRegistrarIngreso').prop('disabled', false).removeClass('disabled');
        } else {
            $('#advertencia_porteria_msg').text(data.mensaje_porteria);
            $('#advertencia_porteria_div').show();
            // Si no está permitido, deshabilitamos el botón de ingreso
            $('#BotonRegistrarIngreso').prop('disabled', true).addClass('disabled');
        }

        // Mostrar botones inteligentes
        if (data.ya_ingreso) {
            $('#BotonRegistrarIngreso').hide();
            $('#BotonRegistrarSalida').show();
            $('#advertencia_porteria_div').hide(); // No mostrar advertencia si ya está adentro
            $('#estado_vehiculo').css('color', '#dc3545').val("YA ESTÁ ADENTRO");
        } else if (data.puesto_lleno) {
            $('#BotonRegistrarIngreso').show().prop('disabled', true).addClass('disabled');
            $('#BotonRegistrarSalida').hide();
            $('#estado_vehiculo').css('color', '#dc3545').val(data.ocupado);
        } else {
            $('#BotonRegistrarSalida').hide();
            $('#estado_vehiculo').css('color', '#28a745').val(data.ocupado);
            if (data.permitido_porteria) {
                $('#BotonRegistrarIngreso').show().prop('disabled', false).removeClass('disabled');
            } else {
                $('#BotonRegistrarIngreso').show().prop('disabled', true).addClass('disabled');
            }
        }

        $('#VerificarIngreso').modal('show');
    }

    function fillModalMulti(results) {
        // Llenar datos generales (del primero)
        $('#identificacion1').val(results[0].cedula);
        $('#nombre1').val(results[0].nombre);
        $('#despacho1').val(results[0].juzgado);

        // Opción 1
        $('#ubicacion_detalle1').val(results[0].ubicacion_detalle);
        $('#estado_vehiculo1').val(results[0].ocupado);
        $('#tipo1').val(results[0].tipo_vehiculo);
        $('#placa1').val(results[0].placa);
        $('#caract1').val(results[0].descripcion_vehiculo);
        $('#id_parq1').val(results[0].id_parq);

        // Lógica de Portería Opción 1
        if (results[0].permitido_porteria) {
            $('#advertencia_porteria_div1').hide();
            $('#BotonRegistrarIngresoVeh').prop('disabled', false).removeClass('disabled');
        } else {
            $('#advertencia_porteria_msg1').text(results[0].mensaje_porteria);
            $('#advertencia_porteria_div1').show();
            $('#BotonRegistrarIngresoVeh').prop('disabled', true).addClass('disabled');
        }

        if (results[0].ya_ingreso) {
            $('#BotonRegistrarIngresoVeh').hide();
            $('#BotonRegistrarSalidaVeh').show();
            $('#advertencia_porteria_div1').hide();
            $('#estado_vehiculo1').css('color', '#dc3545').val("YA ESTÁ ADENTRO");
        } else if (results[0].puesto_lleno) {
            $('#BotonRegistrarIngresoVeh').show().prop('disabled', true).addClass('disabled');
            $('#BotonRegistrarSalidaVeh').hide();
            $('#estado_vehiculo1').css('color', '#dc3545').val(results[0].ocupado);
        } else {
            $('#BotonRegistrarSalidaVeh').hide();
            $('#estado_vehiculo1').css('color', '#28a745').val(results[0].ocupado);
            if (results[0].permitido_porteria) {
                $('#BotonRegistrarIngresoVeh').show().prop('disabled', false).removeClass('disabled');
            } else {
                $('#BotonRegistrarIngresoVeh').show().prop('disabled', true).addClass('disabled');
            }
        }

        // Opción 2
        $('#ubicacion_detalle2').val("results[1].ubicacion_detalle");
        $('#estado_vehiculo2').val(results[1].ocupado);
        $('#tipo2').val(results[1].tipo_vehiculo);
        $('#placa2').val(results[1].placa);
        $('#caract2').val(results[1].descripcion_vehiculo);
        $('#id_parq2').val(results[1].id_parq);

        // Lógica de Portería Opción 2
        if (results[1].permitido_porteria) {
            $('#advertencia_porteria_div2').hide();
            $('#BotonRegistrarIngresoVehdos').prop('disabled', false).removeClass('disabled');
        } else {
            $('#advertencia_porteria_msg2').text(results[1].mensaje_porteria);
            $('#advertencia_porteria_div2').show();
            $('#BotonRegistrarIngresoVehdos').prop('disabled', true).addClass('disabled');
        }

        if (results[1].ya_ingreso) {
            $('#BotonRegistrarIngresoVehdos').hide();
            $('#BotonRegistrarSalidaVehdos').show();
            $('#advertencia_porteria_div2').hide();
            $('#estado_vehiculo2').css('color', '#dc3545').val("YA ESTÁ ADENTRO");
        } else if (results[1].puesto_lleno) {
            $('#BotonRegistrarIngresoVehdos').show().prop('disabled', true).addClass('disabled');
            $('#BotonRegistrarSalidaVehdos').hide();
            $('#estado_vehiculo2').css('color', '#dc3545').val(results[1].ocupado);
        } else {
            $('#BotonRegistrarSalidaVehdos').hide();
            $('#estado_vehiculo2').css('color', '#28a745').val(results[1].ocupado);
            if (results[1].permitido_porteria) {
                $('#BotonRegistrarIngresoVehdos').show().prop('disabled', false).removeClass('disabled');
            } else {
                $('#BotonRegistrarIngresoVehdos').show().prop('disabled', true).addClass('disabled');
            }
        }

        $('#VerificarIngreso2').modal('show');
    }

    // Eventos
    $('#btnUnifiedSearch').click(function() { searchUnified(); });

    // Botones de Registro (Single)
    $('#BotonRegistrarIngreso').click(function(e) {
        e.preventDefault();
        var id = $('#placa').val(); // Usar PLACA en lugar de Cédula
        var parqId = $('#id').val(); // ID único del vehículo
        var url = $('#form-registrar-ingreso').attr('action').replace(':CEDULA_ID', id) + "?parq=" + parqId;

        // Deshabilitar para evitar doble clic
        $(this).prop('disabled', true).text('Registrando...');

        $.get(url, function(res) {
            if (res.status === 0) {
                toastr.success(res.message || 'Ingreso registrado');
                $('#VerificarIngreso').modal('hide');
                refreshBitacora(); // ⌛ Refrescar solo la tabla
            } else {
                toastr.error(res.message);
                if (res.message.toLowerCase().includes('ya se encuentra') || res.message.toLowerCase().includes('adentro') || res.message.toLowerCase().includes('ocupado')) {
                    $('#BotonRegistrarIngreso').hide();
                    $('#BotonRegistrarSalida').show();
                    $('#estado_vehiculo').css('color', '#dc3545').val('OCUPADO');
                }
            }
        }).fail(function(jqXHR) {
            toastr.error('Error del servidor o comunicación fallida.');
        }).always(function() {
            $('#BotonRegistrarIngreso').prop('disabled', false).text('REGISTRAR INGRESO');
        });
    });

    $('#BotonRegistrarSalida').click(function(e) {
        e.preventDefault();

        var id = $('#placa').val(); // Usar PLACA para la salida
        var parqId = $('#id').val();
        if (!id) { toastr.error('Debe ingresar la placa'); return; }

        var baseUrl = $(this).attr('href');
        var url = baseUrl.replace(':CEDULA_ID', id) + "?parq=" + parqId;

        $(this).prop('disabled', true);

        $.get(url, function(res) {
            if (res.status === 0) {
                toastr.success(res.message || 'Salida registrada');
                $('#VerificarIngreso').modal('hide');
                refreshBitacora(); // ⌛ Refrescar solo la tabla
            } else {
                toastr.error(res.message);
            }
        }).fail(function() {
            toastr.error('Error al procesar la solicitud');
        }).always(function() {
            $('#BotonRegistrarSalida').prop('disabled', false);
        });
    });

    /*$('#BotonRegistrarSalida').click(function(e) {
        e.preventDefault();
        var id = $('#identificacion').val();
        var url = $('#form-registrar-salida').attr('action').replace(':CEDULA_ID', id);
        alert(id,url);
        
        $.get(url, function(res) {
            if (res.status === 0) {
                toastr.success(res.message);
                $('#VerificarIngreso').modal('hide');
                setTimeout(() => window.location.reload(), 1000);
            } else {
                toastr.error(res.message);
            }
        });
    });*/

    // Botones Multi-Vehículo
    $('#BotonRegistrarIngresoVeh, #BotonRegistrarIngresoVehdos').click(function(e) {
        e.preventDefault();
        var parq = $(this).attr('id') === 'BotonRegistrarIngresoVeh' ? $('#id_parq1').val() : $('#id_parq2').val();
        var plate = $(this).attr('id') === 'BotonRegistrarIngresoVeh' ? $('#placa1').val() : $('#placa2').val();
        $(this).prop('disabled', true);
        var btn = $(this);

        $.ajax({
            type: "GET",
            url: "/parqueadero/registrar/ingreso/dos/" + plate + "?parq=" + parq,
            success: function(res) {
                if (res.status === 0) {
                    toastr.success(res.message || 'Ingreso registrado');
                    $('#VerificarIngreso2').modal('hide');
                    refreshBitacora(); // ⌛ Refrescar solo la tabla
                } else {
                    toastr.error(res.message);
                    if (res.message.toLowerCase().includes('adentro') || res.message.toLowerCase().includes('ocupado')) {
                         searchUnified();
                    }
                }
            },
            complete: function() { btn.prop('disabled', false); }
        });
    });

    $('#BotonRegistrarSalidaVeh, #BotonRegistrarSalidaVehdos').click(function(e) {
        e.preventDefault();
        var parq = $(this).attr('id') === 'BotonRegistrarSalidaVeh' ? $('#id_parq1').val() : $('#id_parq2').val();
        var plate = $(this).attr('id') === 'BotonRegistrarSalidaVeh' ? $('#placa1').val() : $('#placa2').val();
        $(this).prop('disabled', true);
        var btn = $(this);

        $.ajax({
            type: "GET",
            url: "/parqueadero/registrar/salida/dos/" + plate + "?parq=" + parq,
            success: function(res) {
                if (res.status === 0) {
                    toastr.success(res.message || 'Salida registrada');
                    $('#VerificarIngreso2').modal('hide');
                    refreshBitacora(); // ⌛ Refrescar solo la tabla
                } else {
                    toastr.error(res.message);
                }
            },
            complete: function() { btn.prop('disabled', false); }
        });
    });

});

// ===================================================================
// refreshBitacora: Actualiza la tabla de bitácora via AJAX
// sin recargar toda la página
// ===================================================================
function refreshBitacora() {
    $.ajax({
        url: window.location.href,
        type: 'GET',
        success: function(html) {
            try {
                // Extraer el tbody actualizado de la respuesta
                var newTbody = $(html).find('#tableIngresos tbody').html();
                if (newTbody) {
                    $('#tableIngresos tbody').html(newTbody);
                    // Reaplica los filtros tras la actualización AJAX
                    if (typeof filterTable === 'function') {
                        filterTable();
                    }
                }

                // Actualizar contadores detallados
                ['personas', 'carros', 'motos'].forEach(function(type) {
                    var newCount = $(html).find('#count-' + type).text();
                    if (newCount !== undefined) {
                        $('#count-' + type).text(newCount);
                    }
                });

                // Efecto visual: flash en la tabla
                $('#tableIngresos').fadeOut(150).fadeIn(300);

                // Refrescar enfoque en el campo de búsqueda
                setTimeout(function() {
                    var search = document.getElementById('unifiedSearch');
                    if (search) { search.focus(); search.value = ''; }
                }, 350);
            } catch (e) {
                console.error('Error in refreshBitacora:', e);
                window.location.reload();
            }
        },
        error: function() {
            // Fallback silencioso: no recargar
            console.warn('[refreshBitacora] No se pudo actualizar la tabla.');
        }
    });
} 