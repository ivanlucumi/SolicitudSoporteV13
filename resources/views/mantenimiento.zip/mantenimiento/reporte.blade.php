@extends('layouts.mantenimiento')
<!--ponerle titulo a la paginga-->
@section('title', 'Control Registro De ingreso')
@section('cabecera', 'Control Registro De ingreso Desde Porter&iacute;a')

@section('content') 

<div class="container-fluid">
    <!-- Date dd/mm/yyyy -->
    <div class="form-group">
    {!!Form::model($solicitud,['route'=>['reporte.incidente.save',$solicitud->id], 'method'=>'PUT'])!!}
        {{csrf_field()}}
        <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-6 ">
                  <label>CATEGOR&Iacute;A:</label>
                  <div class="form-group">                              
                      <input type="text" value="{{$solicitud->categoria}}" name="categoria" class="form-control" id="idCategoria" readonly>
                    </div>
              </div>
              <div class="col-xs-12 col-sm-12 col-md-6 ">
                  <label>REPORTE:</label>
                  <div class="form-group">                              
                      <input type="text" name="reporte" value="{{$solicitud->item}}" class="form-control" id="idIReporte" readonly>
                    </div>
              </div>
              <div class="col-xs-12 col-sm-12 col-md-12 ">
                  <label>DESCRIPCI&Oacute;N:</label>
                  <div class="form-group">
                    <textarea name="textarea" value="{{$solicitud->descripcion}}" style="height: 10em;width: 100%" id="idDescripcion"readonly></textarea>
                  </div>
              </div>
              
      
          
            <div class="col-xs-12 col-sm-12 col-md-6">
                  <!-- Date -->
               <div class="form-group">
                    <label>FECHA REPORTE:</label>
                    <input type="text" name="fecha_ingreso" value="{{$solicitud->created_at}}" placeholder="Ingresa Fecha de visita" class="form-control" readonly required/>
               </div>                        
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 ">
                  <!-- Date -->
               <div class="form-group">
                    <label>ESTADO:</label>
                    <input type="text" class="form-control" value="{{$solicitud->estado}}" name="radicado" id='nProceso' readonly required/>
               </div>                        
            </div>
        
        
        <div class="col-xs-12 col-sm-12 col-md-6">
          <div class="form-group">
            {!!Form::label('trasladado','TRASLADAR A:')!!}<br>
            {!!Form::select('trasladado_a',$mantenimiento,null,['placeholder'=>'Seleccione Jefe mantenimiento','class'=>'form-control'])!!}<br>
            
          </div>
          
      </div>
      <div class="col-xs-12 col-sm-12 col-md-6">
        <div class="form-group">
          
            {!!Form::label('asignado','ASIGNAR A:')!!}<br>
            {!!Form::select('asignado_a',$operario,null,['placeholder'=>'Seleccione Operario Mantenimiento','class'=>'form-control'])!!}
            
        </div>
        
    </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
            <label>OBSERVACIONES:</label>
                {!!Form::textarea('observaciones',null,['placeholder'=>'Descripcion de la solución','class'=>'form-control','required','style'=>"height: 10em;width: 100%"])!!}
            </div>
            
        </div>

    </div>
    
  </div>
  </div>
  <div class="row">
    <div class="col-xs-3 form-group">
        <button onClick={() => this.handleRowClick(ticket)}></button>
    </div>
    <div class="col-xs-3 form-group">
        {!!Form::submit('Generar',['class'=>'btn btn-primary btn-block'])!!}
    </div>
    <div class="col-xs-3 form-group">
        {!!Form::submit('Generar',['class'=>'btn btn-primary btn-block'])!!}
    </div>
    <div class="col-xs-3 form-group">
        <a href="{!! URL::previous()!!}" class="btn btn-danger btn-block">Cancelar</a>
        {!!Form::close()!!}
    </div>
    
</div>
  
  @push('scripts')
  <script>
   
  </script>
@endpush
    

 
 
@endsection


