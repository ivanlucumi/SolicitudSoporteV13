<!-- MODAl PARA EDITAR-->  
<div class="modal fade" id="modal_Revisar_reporte_operario">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header text-center " style="background-color: #007d6e;">
          <h4 class="modal-title pull-center" style="justify-content: center; color:white"><strong>VER Y ASIGNAR REPORTE DE INCIDENTE</strong> </h4>                
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">                 
           <span aria-hidden="true">&times;</span></button>                             
        </div>
        <div id="msj-error" class="alert alert-danger alert-dismissible" role="alert" style="display:none">
            <strong id="msj"></strong>
          </div> 
          <div class="card-body">
            <div class="container-fluid">
            <!-- Date dd/mm/yyyy -->
            <div class="form-group">
              {!!Form::open(['route'=>'operario.reporte.incidente.save', 'method'=>'POST'])!!}
                {{csrf_field()}}
                  <div class="row">
                    <input type="hidden" name="id" class="form-control" id="id" readonly>
                      <div class="col-xs-12 col-sm-12 col-md-6 ">
                          <label>CATEGOR&Iacute;A:</label>
                          <div class="form-group">                              
                              <input type="text" name="categoria" class="form-control" id="idCategoria" readonly>
                            </div>
                      </div>
                      <div class="col-xs-12 col-sm-12 col-md-6 ">
                          <label>REPORTE:</label>
                          <div class="form-group">                              
                              <input type="text" name="reporte" class="form-control" id="IdItem" readonly>
                            </div>
                      </div>
                      <div class="col-xs-12 col-sm-12 col-md-12 ">
                          <label>DESCRIPCI&Oacute;N:</label>
                          <div class="form-group">
                            <textarea name="descripcion_" style="height: 10em;width: 100%" id="idDescripcion"readonly></textarea>
                          </div>
                      </div>
                      
              
                  
                    <div class="col-xs-12 col-sm-12 col-md-6">
                          <!-- Date -->
                       <div class="form-group">
                            <label>FECHA REPORTE:</label>
                            <input type="text" name="fecha_reporte" placeholder="Ingresa Fecha de visita" id="IdFecha" class="form-control" readonly required/>
                       </div>                        
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-6 ">
                          <!-- Date -->
                       <div class="form-group">
                            <label>ESTADO:</label>
                            <input type="text" class="form-control" name="radicado" id='IdEstado' readonly required/>
                       </div>                        
                    </div>
                
                  
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                        <label>OBSERVACIONES:</label>
                            {!!Form::textarea('observaciones',null,['placeholder'=>'Descripcion de la solución','class'=>'form-control','readonly','required','id'=>'Idobservaciones','style'=>"height: 10em;width: 100%"])!!}
                        </div>
                        
                    </div>
            </div>
            
          </div>
          </div>
         </div>
         
        <div class="modal-footer">
          <div class="container-fluid">
            <div class="row"> 
               
               {!!Form::close()!!}             
              
              <div class="col-xs-12 ">
                <a class="btn bg-elegant btn-warning btn-block " data-dismiss="modal">CANCELAR</a>                         
              </div>

            </div>
          </div>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->
  </div>

  