@extends('layouts.mantenimiento')
<!--ponerle titulo a la paginga-->
@section('title', 'Reporte de Incidentes')
@section('cabecera', 'Reporte de Incidentes Cerrados')



@section('content') 

<div class="container-fluid">



<div class="row">
  <div class="col-xs-1">

  </div>
  <div class="col-xs-10">
    <div class="card mb-3" >
        <div class="row no-gutters">
          
          <div class="col-md-12">
            <div class="card-body">
              <p class="card-text"><h2><strong><center>LISTADO DE INCIDENTES REPORTADOS YA CERRADOS</center></strong></h2> </p>
              <br>
              
             </div>
          </div>
        </div>
      </div>
  </div> 
  <div class="col-xs-1">

  </div>       
</div>

<div class="row">
        <div class="box-body">
          <div class="row">
            <div class="table-responsive">
                <table id="table9" class="table table-bordered table-striped" >
                  <thead class="shadow" style="background-color: #007d6e; color: #fff;">
                    <tr>
                        <th>CATEGORIA</th>
                        <th>REPORTE</th>
                        <th>DESCRIPCION</th>	
                        <th>DESPACHO</th>	
                        <th>ESTADO</th>
                        <th>FECHA</th>
                        <th>ASIGNADO A</th>
                        <th>TRASLADADO A</th>
                        <th>OBSERVACIONES</th>
                        <th>RESPUESTA TECNICO</th>
                        <th>ACCION</th>
                        
                                              
                    </tr>
                  </thead>


                  @if($incidentes != null)
                      @foreach($incidentes as $solicitud)
                              <tbody data-id="{!!$solicitud->id!!}"  class="buscar">
                                      <tr class="table-light">
                                          <th scope="row"> {{$solicitud->categoria}} </th>
                                          <th scope="row"> {{$solicitud->item}}  </th>
                                          <th scope="row"> {{$solicitud->descripcion}} </th>
                                          <th scope="row"> {{$solicitud->nombre_usuario}} </th>
                                          <th scope="row"> {{$solicitud->estado}} </th>
                                          <th scope="row"> {{$solicitud->created_at}} </th>
                                          <th scope="row"> {{$solicitud->asignado_a}} </th>
                                          <th scope="row"> {{$solicitud->trasladado_a}} </th>
                                          <th scope="row"> {{$solicitud->observaciones}} </th>
                                          <th scope="row"> {{$solicitud->respuesta_tecnico}} </th>
                                          <th scope="row"> {!!link_to('#',$title = '', $attributes = ['class'=>'btn btn-success btn-sm 
                                            fa fa-eye ver',$secure = null,'id'=>'ver','title' => 'Ver'])!!}
                                            {!!link_to('#',$title = '', $attributes = ['class'=>'btn btn-success btn-sm 
                                            fa fa-exchange trasladar',$secure = null,'id'=>'trasladar','title' => 'Trasladar'])!!}
                                            {!!link_to('#',$title = '', $attributes = ['class'=>'btn btn-success btn-sm 
                                            fa fa-lock cerrar',$secure = null,'id'=>'registrar','title' => 'cerrar'])!!}

                                          </th>
                                          
                                          
                                      </tr>								 	                
                              </tbody>
                      @endforeach	  
                  @else
                        
                        @endif					
                      
                                  
                </table>
            </div>
          </div>
        </div>
  </div>

</div>

@include('mantenimiento.modal.revision')
@include('mantenimiento.modal.cerrar')
@include('mantenimiento.modal.trasladar')

<!--CONSULTA INGRESO -->
{!!Form::open(['id'=>'form-reporte-incidente','route'=>['reporte.incidente',':ID_ID'], 'method'=>'GET'])!!}
{!!Form::close()!!}

{!!Html::script('/js/jquery.js')!!}
{!!Html::script('/tablefilter/tablefilter.js')!!}
{!!Html::script('/js/FilerOnce.js')!!}

<script>

$('.ver').click(function(e) {
  //alert('hola')
  e.preventDefault();           
  var row   = $(this).parents('tbody')
  var id    = row.data('id');
  //alert(id);
  var form  = $('#form-reporte-incidente');
  var url   = form.attr('action').replace(':ID_ID', id);
  var data  = form.serialize();
  //alert(url);
  $.get(url,data, function(result){
      console.log(result)
        $('#id').val(result.id);
        $('#idCategoria').val(result.categoria);       
        $('#IdItem').val(result.item); 
        $('#idDescripcion').val(result.descripcion);
        $('#IdFecha').val(result.created_at); 
        $('#idIReporte').val(result.marca); 
        $('#IdEstado').val(result.estado);
        $('#Idobservaciones').val(result.observaciones);
        $('#modal_Revisar_reporte').modal('show');
  });
 });

 $('.trasladar').click(function(e) {
  //alert('hola')
  e.preventDefault();           
  var row   = $(this).parents('tbody')
  var id    = row.data('id');
  //alert(id);
  var form  = $('#form-reporte-incidente');
  var url   = form.attr('action').replace(':ID_ID', id);
  var data  = form.serialize();
  //alert(url);
  $.get(url,data, function(result){
      console.log(result)
        $('#idt').val(result.id);
        $('#idCategoriat').val(result.categoria);       
        $('#IdItemt').val(result.item); 
        $('#idDescripciont').val(result.descripcion);
        $('#IdFechat').val(result.created_at); 
        $('#idIReportet').val(result.marca); 
        $('#IdEstadot').val(result.estado);
        $('#Idobservacionet').val(result.observaciones);
        $('#modal_trasladar_reporte').modal('show');
  });
 });

 $('.cerrar').click(function(e) {
  //alert('hola')
  e.preventDefault();           
  var row   = $(this).parents('tbody')
  var id    = row.data('id');
  //alert(id);
  var form  = $('#form-reporte-incidente');
  var url   = form.attr('action').replace(':ID_ID', id);
  var data  = form.serialize();
  //alert(url);
  $.get(url,data, function(result){
      console.log(result)
        $('#idc').val(result.id);
        $('#idCategoriac').val(result.categoria);       
        $('#IdItemc').val(result.item); 
        $('#idDescripcionc').val(result.descripcion);
        $('#IdFechac').val(result.created_at); 
        $('#idIReportec').val(result.marca); 
        $('#IdEstadoc').val(result.estado);
        $('#Idobservacionec').val(result.observaciones);        
        $('#Idrepuesta').val(result.respuesta_tecnico);
        $('#modal_cerrar_reporte').modal('show');
  });
 });
               
</script>


@endsection