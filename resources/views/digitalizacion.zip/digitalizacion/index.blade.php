@extends('layouts.digitalizacion.digitalizacion')
<!--ponerle titulo a la paginga-->
@section('title', 'Solicitudes de Usuarios')
@section('cabecera', 'Solicitudes enviadas y sin resolver')

@section('content') 
<div class="container-fluid">
    <div class="" style="text-align: right">
      <nav class="navbar navbar-light bg-light">
        {!!Form::open(['route'=>['tecnico.solicitud'], 'method'=>'GET'])!!}
        {!!Form::number('radicado',null,['class'=>'form-group mr-sm-2 shadow','placeholder'=>'Buscar por radicado','autocomplete'=>'off','aria-label'=>"Search"])!!}
          <button class="form-group btn btn-success my-2 my-sm-0 shadow" type="submit">Buscar</button>
        {!!Form::close()!!}
      </nav>
    </div>
    
  </div>
<hr>
{!!Html::script('/js/jquery.js')!!}
{!!Html::script('/tablefilter/tablefilter.js')!!}     

@endsection