
<div class="row ">

    <div class="col-xs-6 col-sm-4 form-group ">

        {!!Form::label('fechaA','Programar Fecha:')!!}

        {!!Form::date('fecha_prgramada',$solicitudAudiencia->fecha_prgramada,['class'=>'form-control','shadow','required', 'autocomplete'=>"off",'readonly'])!!}

    </div>

    <div class="col-xs-6 col-sm-4 form-group ">

        {!!Form::label('horaI','Hora inicio:')!!}

        {!!Form::text('hora_inicio',$solicitudAudiencia->hora_inicio,['class'=>'form-control','shadow','required','id'=>'timepicker', 'autocomplete'=>"off",'placeholder'=>'Ingrese formato militar (24 horas)','required','readonly'])!!}

    </div>

    <div class="col-xs-6 col-sm-4  form-group ">

        {!!Form::label('horaF','Hora finalización:')!!}

        {!!Form::text('hora_fin',$solicitudAudiencia->hora_fin,['class'=>'form-control','shadow','required','id'=>'timepicker2','placeholder'=>'Ingrese formato militar (24 horas)', 'autocomplete'=>"off", 'required','readonly'])!!}

    </div>

    

</div>

<div class="row ">

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('ciudad','Ciudad origen de la audiencia:')!!}

        {!!Form::text('ciudad_destino',$solicitudAudiencia->ciudad_destino,['class'=>'form-control','shadow','required','placeholder'=>'Ingrese Ciudad de la Audiencia', 'autocomplete'=>"off",'readonly'])!!}

    </div>

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('entidadDest','Demandante:')!!}

        {!!Form::text('entidad_destino',$solicitudAudiencia->entidad_destino,['class'=>'form-control','shadow','required','placeholder'=>'Ingrese Demandante', 'autocomplete'=>"off",'readonly'])!!}

    </div>

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('nRadicacion','Número de radicaci&oacute;n del proceso:')!!}

        {!!Form::number('numero_radicado_proceso',$solicitudAudiencia->numero_radicado_proceso,['class'=>'form-control','shadow','id'=>'nProceso',/*'onkeyup'=>"validarcantidad(this)",*/'min'=>'1','required','placeholder'=>'Ingrese número de radicado','readonly'])!!}

        <div id="cantidad"></div>

    </div>

</div>

<div class="row ">

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('decoindi','Declarante, Demandado o Indiciado?:')!!}

        {!!Form::text('declarante_indiciado',$solicitudAudiencia->declarante_indiciado,['class'=>'form-control','shadow','required','placeholder'=>'Ingrese nombre', 'autocomplete'=>"off",'readonly'])!!}

    </div>

    <div class="col-xs-12 col-sm-6 col-md-3 form-group " style="display:none">

        {!!Form::label('direccion','Dirección:')!!}

        {!!Form::text('direccion',$solicitudAudiencia->direccion ,['class'=>'form-control','shadow','placeholder'=>'Ingrese la dirección', 'autocomplete'=>"off",'readonly'])!!}

    </div>

    <div class="col-xs-12 col-sm-6 col-md-2 form-group ">

        {!!Form::label('telefono','Teléfono del solicitante:')!!}

        {!!Form::number('telefono',$solicitudAudiencia->telefono,['class'=>'form-control','shadow','required','min'=>'1','placeholder'=>'Ingrese número de tel&eacute;fono', 'autocomplete'=>"off",'readonly'])!!}

    </div>
    
     <div class="col-xs-12 col-sm-3 col-md-2 form-group ">

        {!!Form::label('fecha_solicitud','Fecha solicitud:')!!}

        {!!Form::datetime('fecha_solicitud',$solicitudAudiencia->fecha_solicitud,['class'=>'form-control','shadow','required','placeholder'=>'Fecha solicitud', 'autocomplete'=>"off",'readonly'])!!}

    </div>
     <div class="col-xs-12 col-sm-6 col-md-3 form-group ">

        {!!Form::label('detenido','Audiencia con detenidos(s) a cargo del inpec?')!!}

        <div class="row">

            <div class="col-xs-12 col-lg-6">

            <label><input type="radio" id="cbox1" value="1" name="detenido" onClick="condetenido()" disabled @if($solicitudAudiencia->detenido == '1')

                <?php echo 'checked'; ?>

            @endif   > SI</label>

            </div>

            <div class="col-xs-12 col-lg-6">

                <label><input type="radio" id="cbox2" value="0" name="detenido" onClick="sindetenido()" disabled @if($solicitudAudiencia->detenido == '0')

                  <?php echo 'checked'; ?>

                @endif > NO</label>

            </div>

        </div>

        

    </div>
   

</div>

<div class="row ">

   
      <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('auprivada','La audiencia es reservada ?')!!}

        <div class="row">

            <div class="col-xs-12 col-lg-6">

                <label><input type="radio" id="cbox2" value="1" name="audiencia_privada" disabled @if($solicitudAudiencia->audiencia_privada == '1')

                    <?php echo 'checked'; ?>

                @endif > SI</label>

                </div>

                <div class="col-xs-12 col-lg-6">

                    <label><input type="radio" id="cbox2" value="0" name="audiencia_privada" disabled @if($solicitudAudiencia->audiencia_privada == '0')

                      <?php echo 'checked'; ?>

                    @endif > NO</label>

                </div>

        </div>

        

    </div>
     <div class="col-xs-12 col-sm-5 col-md-5 form-group ">

        {!!Form::label('enlace','Url Conexión:')!!}

        {!!Form::text('enlace',$solicitudAudiencia->enlace,['class'=>'form-control','shadow','min'=>'1','placeholder'=>'Url conexión lifesize', 'autocomplete'=>"off"])!!}

    </div>
    <div class="col-xs-12 col-sm-3 col-md-3 form-group ">

        {!!Form::label('id_conexion','Id Conexión:')!!}

        {!!Form::text('id_conexion',$solicitudAudiencia->id_conexion,['class'=>'form-control','shadow','min'=>'1','placeholder'=>'id lifesize', 'autocomplete'=>"off"])!!}

    </div>
   
   

</div>


@if($solicitudAudiencia->detenido == 1)

     <div class="row">

            
            <div class="col-md-12">

                <center><h2><strong> LISTA DE DETENIDOS QUE ASISTIRÁN</strong></h2></center>

                <table class="table text-center table-bordered" ><!--Creamos una tabla que mostrará todas las tareas-->

                        <thead style="background-color: #007d6e;">

                            <tr>

                                <th scope="col">NOMBRE</th>

                                <th scope="col">CIUDAD</th>

                                <th scope="col">NOMBRE ESTABLECIIENTO</th>

                                <th scope="col">Acciones</th>

                            </tr>

                        </thead>

                        @foreach($solicitudAudiencia->Detenidos as $detenido)

                            <tbody data-id="{!!$detenido->id!!}">

                            <tr>

                                <td>{{$detenido->nombre_interno}}</td>

                                <td>{{$detenido->ciudad}}</td>

                                <td>{{$detenido->nombre_estalecimiento}}</td> 

                            </tr>

                            </tbody>

                        @endforeach

                    </table>

            </div>

        </div>

 @endif

 <script>
  
            

    //solo numeros
     let numerico = document.querySelector('#nProceso').addEventListener('keypress', validaNumericos);
    
        function validaNumericos(e) {
            var key = window.event ? e.which : e.keyCode;
            if (key < 48 || key > 57) {
                e.preventDefault();
            }
        }
    
     /*LIMITAR A SOLO 23 DIGITOS EL NUMERO DEL RADICADO DEL PROCESO*/
    var input = document.getElementById('nProceso');
    input.addEventListener('input', function() {
        if (this.value.length > 23)
            this.value = this.value.slice(0, 23);
    })


    //verificar los 23 digitos
    var input = document.getElementById('nProceso');
    input.addEventListener('input', function() {
        var maxLength = 23;
        if (this.value.length > 23) {
            document.getElementById("cantidad").innerHTML = '<strong> <span style="color: red;">' + this.value.length + ' de ' + maxLength + ' dígitos</span></strong>';
        }
        if (this.value.length === 23) {
            document.getElementById("cantidad").innerHTML = '<strong> <span style="color: green;">' + ' Ya esta completo los ' + maxLength + ' dígitos</span></strong>';
        } else {
            document.getElementById("cantidad").innerHTML = '<strong> <span style="color: red;">' + this.value.length + ' de ' + maxLength + ' dígitos</span></strong>';
        }
    })
 

    
</script>