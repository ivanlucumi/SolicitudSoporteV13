@extends('layouts.tecnicos')
<!--ponerle titulo a la paginga-->
@section('title', 'Solicitud Audiencia Agendada')
@section('cabecera', ' Agendadas Por Mi ')

@section('content') 

<div class="" style="text-align: left">	
	<a href="{!! URL::to('tecnico/solicitudes/agendadas')!!}" class="btn btn-warning btn-sm" >Audiencias </a>
</div>

<div class="container-fluid">
  <div class="" style="text-align: right">
    <nav class="navbar navbar-light bg-light">
      {!!Form::open(['route'=>['agendadas.por.tecnico'], 'method'=>'GET'])!!}
      
        {!!Form::date('fecha',null,['class'=>'form-group mr-sm-2 shadow','placeholder'=>'Buscar por fecha','autocomplete'=>'off','aria-label'=>"Search"])!!}	
        {!!Form::email('email',null,['class'=>'form-group mr-sm-2 shadow','placeholder'=>'Buscar por Email','autocomplete'=>'off','aria-label'=>"Search"])!!}
        {!!Form::number('radicado',null,['class'=>'form-group mr-sm-2 shadow','placeholder'=>'Buscar por radicado','autocomplete'=>'off','aria-label'=>"Search"])!!}
        {!!Form::text('ciudad',null,['class'=>'form-group mr-sm-2 shadow','placeholder'=>'Buscar por ciudad','autocomplete'=>'off','aria-label'=>"Search"])!!}
        <button class="form-group btn btn-success my-2 my-sm-0 shadow" type="submit">Buscar</button>
      {!!Form::close()!!}
    </nav>
  </div>
  
</div>




<div class="table-responsive shadow">
	<table id="table9" class="table  table-hover table-condensed table-bordered " style="display: block;
  overflow: auto;
  width: 100%;
  height: 800px">
	
	</div>	
	    <thead class="shadow" style="background-color: #007d6e; color: #fff;">
		    <tr class="shadow">
		        <th>EDITAR</th>
		        <th>EMAIL</th>
				<th>NOMBRE ENTIDAD</th>
				<th>FECHA PROGRAMADA</th>
				<th>INICIO</th>
				<th>FIN</th>					     
				<th>RADICADO</th>
				<th>ID</th>					     
                <th>URL</th>						     
				
		    </tr>
	    </thead>
      
            @if($solicitudes != null)
            @foreach($solicitudes as $solicitud)
            <tbody data-id="{!!$solicitud->id!!}" class="buscar " >
                <tr class="table-light">
                    <th>{!!link_to_route('tecnico.corregir.audiencia', $title = ' ', $parameters = $solicitud->id, $attributes = ['class'=>'btn btn-primary fa fa-pencil'])!!}</th>
                    <th scope="row">{{$solicitud->email}}</th>									
                    <th >{{$solicitud->nombre_entidad}}</th>
                    <th scope="row">{{$solicitud->fecha_prgramada}}</th>
                    <th scope="row">{{$solicitud->hora_inicio}}</th>									
                    <th scope="row">{{$solicitud->hora_fin}}</th>						
                    <th scope="row">{{$solicitud->numero_radicado_proceso}}</th>
                    <th scope="row">{{$solicitud->id_conexion}}</th>
                    <th scope="row">{{$solicitud->enlace}}</th>

                    
                    </th>        
                </tr>	                
            </tbody>
            @endforeach
        @else
        <tr class="table-light">
            <p class="lead">Actualmente esta secion no cuenta con información disponible, lo invitamos a seguir navegando en las demás pestañas.</p3>
        </tr>
        @endif
	
	</table>
  
</div>


{!!Form::open(['route'=>['tecnico.verificar.estado.solicitud',':ESTADO_ID'], 'method'=>'GET','id'=>'form-verificar-disponibilidad'])!!}
{{csrf_field()}} 
{!!Form::close()!!}




<div class="container-fluid">
    @include('audiencias.tecnico.modal.modal_revisar_solicitud',['solicitudAudiencia'=> $solicitudAudiencia,
             'url'=> 'virtual.audiencia.confirmar', 'method'=>'POST'])   
 </div>
   
  @push('scripts')
    
{!!Html::script('/js/jquery.js')!!}
{!!Html::script('/tablefilter/tablefilter.js')!!}
{!!Html::script('/js/audiencias/filtroaudienciatecnico.js')!!}  
{!!Html::script('/js/audiencias/tecnico.js')!!} 

  @endpush

@endsection