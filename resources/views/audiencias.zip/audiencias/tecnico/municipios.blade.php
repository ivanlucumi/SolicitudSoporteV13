@extends('layouts.tecnicos')
<!--ponerle titulo a la paginga-->
@section('title', 'Solicitud Audiencia Municipios')
@section('cabecera', ' Solicitud de Audiencia Municipios')

@section('content') 

<div class="" style="text-align: left">	
	<a href="{!! URL::to('tecnicos/mcipios')!!}" class="btn btn-warning btn-sm" >Audiencias Municipios</a>
</div>

<div class="container-fluid">
  <div class="" style="text-align: right">
    <nav class="navbar navbar-light bg-light">
      {!!Form::open(['route'=>['tecnico.solicitud.mcipios'], 'method'=>'GET'])!!}
      
        {!!Form::date('fecha',null,['class'=>'form-group mr-sm-2 shadow','placeholder'=>'Buscar por fecha','autocomplete'=>'off','aria-label'=>"Search"])!!}	
        {!!Form::email('email',null,['class'=>'form-group mr-sm-2 shadow','placeholder'=>'Buscar por Email','autocomplete'=>'off','aria-label'=>"Search"])!!}
        {!!Form::number('radicado',null,['class'=>'form-group mr-sm-2 shadow','placeholder'=>'Buscar por radicado','autocomplete'=>'off','aria-label'=>"Search"])!!}
        <button class="form-group btn btn-success my-2 my-sm-0 shadow" type="submit">Buscar</button>
      {!!Form::close()!!}
    </nav>
  </div>
  
</div>


<div class="table-responsive shadow">
	<table id="table9" class="table  table-hover table-condensed table-bordered " style="display: block;
  overflow: auto;
  width: 100%;
  height: 800px">
	
	</div>	
	    <thead class="shadow" style="background-color: #007d6e; color: #fff;">
		    <tr class="shadow">
		        <th>EMAIL</th>
				<th>NOMBRE ENTIDAD</th>
				<th>FECHA PROGRAMADA</th>
				<th>INICIO</th>
				<th>FIN</th>
				<th>CIUDAD</th>
				<th>ENTIDAD</th>					     
				<th>RADICADO</th>
				<th>F. SOLICITUD</th>
				<th>PRIVADA</th>
				<th>DECLARANTE O INDICIADO</th>	
				<th>TELEFONO</th>
				<th>ID</th>					     
                <th>URL</th>	
                <th>RESERVA</th>
                <th scope="col">C&Aacute;RCEL</th>
				
		    </tr>
	    </thead>
      
            @if($solicitudes != null)
            @foreach($solicitudes as $solicitud)
            <tbody data-id="{!!$solicitud->id!!}" class="buscar " >
                <tr class="table-light"  
                @if($solicitud->quien_asigno == Auth::user()->id)
                <?php echo 'style="background-color: #C3F8BC"'; ?>
                @endif
                @if($solicitud->quien_asigno == null)                 
                <?php echo 'style="background-color: #"'; ?>
                @endif
                @if($solicitud->quien_asigno != Auth::user()->id)
                <?php echo 'style="background-color: #FBBAB4"'; ?>
                @endif>
                    <th scope="row">{{$solicitud->email}}</th>									
                    <th scope="row">{{$solicitud->nombre_entidad}}</th>
                    <th scope="row">{{$solicitud->fecha_prgramada}}</th>
                    <th scope="row">{{$solicitud->hora_inicio}}</th>									
                    <th scope="row">{{$solicitud->hora_fin}}</th>									
                    <th scope="row">{{$solicitud->ciudad_destino}}</th>
                    <th scope="row">{{$solicitud->entidad_destino}}</th>					
                    <th scope="row">{{$solicitud->numero_radicado_proceso}}</th>
                    <th scope="row">{{$solicitud->fecha_solicitud}}</th>
                    <th scope="row">@if($solicitud->audiencia_privada == 1)
                                    SI
                                    @else
                                    NO
                                    @endif
                    </th>
                    <th scope="row">{{$solicitud->declarante_indiciado}}</th>	
                    <th scope="row">{{$solicitud->telefono}}</th>

                     {!!Form::model($solicitud,['route'=>['tecnico.almacenar.solicitud.municipio',$solicitud->id], 'method'=>'PUT'])!!}          
                        {{csrf_field()}}
                    <th scope="row"><input type="hidden" name="id_r" value="{{$solicitud->id}}"><input type="text" id="inputId{{$solicitud->id}}" name="id_conexion" required  
                      @if($solicitud->quien_asigno != Auth::user()->id)
                      <?php echo 'disabled="disabled"'; ?>                      
                      @endif></th>              
                    <th scope="row"><input type="text" id="inputUrl{{$solicitud->id}}" name="url_conexion" required
                      @if($solicitud->quien_asigno != Auth::user()->id)
                      <?php echo 'disabled="disabled"'; ?>                      
                      @endif></th>      
                    <th>
                       <center>
                        @if($solicitud->quien_asigno == Auth::user()->id)
                         {!!Form::submit('Guardar',['class'=>'fa fa-save btn btn-success btn-block elevation-3'])!!}                        
                         {!!Form::close()!!}
                         <!-- soltar-->
                         {!!Form::model($solicitud,['route'=>['tecnico.soltar.estado.solicitud.municipio',$solicitud->id], 'method'=>'PUT'])!!}          
                            {{csrf_field()}}
                            {!!Form::submit('Soltar',['class'=>'fa fa-save btn btn-warning btn-block elevation-3'])!!}                        
                         {!!Form::close()!!}
                             
                        @endif
                        @if($solicitud->quien_asigno == null)
                        <button class="btn btn-warning btn-block boton-asignar-tecnico-audienciaV">ok</button>
                        @endif
                        @if($solicitud->quien_asigno != Auth::user()->id)
                        
                        @endif
                        
                       </center>
                    </th>  
                    <th>
                     @foreach($solicitud->Detenidos as $detenido)
                        {{$detenido->ciudad}} -> {{$detenido->nombre_estalecimiento}}<br>
                     @endforeach
                    </th>
                </tr>	                
            </tbody>
            @endforeach
        @else
        <tr class="table-light">
            <p class="lead">Actualmente esta secion no cuenta con información disponible, lo invitamos a seguir navegando en las demás pestañas.</p3>
        </tr>
        @endif
	
	</table>
</div>


{!!Form::open(['route'=>['tecnico.verificar.estado.solicitud',':ESTADO_ID'], 'method'=>'GET','id'=>'form-verificar-disponibilidad'])!!}
{{csrf_field()}} 
{!!Form::close()!!}





<div class="container-fluid">
    @include('audiencias.tecnico.modal.modal_revisar_solicitud',['solicitudAudiencia'=> $solicitudAudiencia,
             'url'=> 'virtual.audiencia.confirmar', 'method'=>'POST'])   
 </div>
   
  @push('scripts')
    
{!!Html::script('/js/jquery.js')!!}
{!!Html::script('/tablefilter/tablefilter.js')!!}
{!!Html::script('/js/audiencias/filtroaudiencias.js')!!}  
{!!Html::script('/js/audiencias/tecnico.js')!!} 

  @endpush

@endsection