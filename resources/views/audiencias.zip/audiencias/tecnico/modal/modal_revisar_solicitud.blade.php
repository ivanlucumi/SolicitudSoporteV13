<!-- MODAl PARA EDITAR-->  
<div class="modal fade" id="modal_revisar_solicitud">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header text-center " style="background-color: #007d6e;">
          <h4 class="modal-title pull-center" style="justify-content: center; color:white"><strong>DATOSDE LA SOLICITUD</strong> </h4>                
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">                 
           <span aria-hidden="true">&times;</span></button>                             
        </div>
        <div id="msj-error" class="alert alert-danger alert-dismissible" role="alert" style="display:none">
            <strong id="msj"></strong>
          </div> 
        
         <div class="modal-body">
           <div class="container-fluid">
             {!!Form::open(['route'=>$url, 'method'=>$method,'id' => 'form-almacenar-detenido'])!!} 
              {{csrf_field()}} 

            {!!Form::hidden('solicitud_audiencias_id', null ,['class'=>'form-control','required','id'=>'idsoli'])!!}
            <div class="row was-validated">
                <div class="col-xs-12 col-sm-4 form-group ">
                    {!!Form::label('fechaA','Programar Fecha:')!!}
                    {!!Form::text('fecha_prgramada',null,['class'=>'form-control','shadow','required','id'=>'fecha_prgramada','readonly'])!!}
                </div>
                <div class="col-xs-6 col-lg-4 form-group ">
                    {!!Form::label('horaI','Hora Inicio:')!!}
                    {!!Form::time('hora_inicio',null,['class'=>'form-control','shadow','id'=>'hora_inicio','required','step'=>'0000','readonly'])!!}
                </div>
                <div class="col-xs-6 col-lg-4  form-group ">
                    {!!Form::label('horaF','Hora Finalización:')!!}
                    {!!Form::time('hora_fin',null,['class'=>'form-control','shadow','required', 'id'=>"hora_fin",'readonly'])!!}
                </div>
                <div class="col-xs-6 col-lg-6 form-group ">
                    {!!Form::label('email','Correo:')!!}
                    {!!Form::email('email',null,['class'=>'form-control','shadow','required', 'id'=>"email",'placeholder'=>'Correo del despacho que solicita','readonly'])!!}
                </div>
                <div class="col-xs-6 col-lg-6  form-group ">
                    {!!Form::label('nombre_entidad','Nombre Entidad:')!!}
                    {!!Form::text('nombre_entidad',null,['class'=>'form-control', 'id'=>"nombre_entidad",'shadow','required','placeholder'=>'Nombre','readonly'])!!}
                </div>
                <div class="col-xs-12 col-sm-6  form-group ">
                    {!!Form::label('ciudad','Ciudad destino de la audiencia:')!!}
                    {!!Form::text('ciudad_destino',null,['class'=>'form-control', 'id'=>"ciudad_destino",'shadow','required','placeholder'=>'Inresa Ciudad de la Audiencia','readonly'])!!}
                </div>
                <div class="col-xs-12 col-sm-6 form-group ">
                    {!!Form::label('entidadDest','Entidad Destino de la Audiencia:')!!}
                    {!!Form::text('entidad_destino',null,['class'=>'form-control', 'id'=>"entidad_destino",'shadow','required','placeholder'=>'Ingresa entidad destino de la audicencia','readonly'])!!}
                </div>
            </div>
            <div class="row was-validated">                
              
                <div class="col-xs-12 col-sm-6  form-group ">
                    {!!Form::label('nRadicacion','Numero de Radicacion del proceso:')!!}
                    {!!Form::number('numero_radicado_proceso',null,['class'=>'form-control','id'=>"numero_radicado_proceso",'shadow','onkeyup'=>"validarcantidad(this)",'min'=>'1','required','placeholder'=>'Ingresa número de radicado','readonly'])!!}
                    <div id="cantidad"></div>
                </div>
                <div class="col-xs-12 col-sm-6  form-group ">
                    {!!Form::label('decoindi','Declarante o Indiciado?:')!!}
                    {!!Form::text('declarante_indiciado',null,['class'=>'form-control','id'=>"declarante_indiciado",'shadow','required','placeholder'=>'Ingresa nombre del declarante o indiciado','readonly'])!!}
                </div>
            </div>
            <div class="row was-validated">
                
                <div class="col-xs-12 col-sm-6  form-group ">
                    {!!Form::label('direccion','Dirección:')!!}
                    {!!Form::text('direccion',null ,['class'=>'form-control','id'=>"direccion",'shadow','required','placeholder'=>'Ingresa la dirección','readonly'])!!}
                </div>
                <div class="col-xs-12 col-sm-6  form-group ">
                    {!!Form::label('telefono','Teléfono del Solicitante:')!!}
                    {!!Form::number('telefono',null,['class'=>'form-control','id'=>"telefono",'shadow','required','min'=>'1','placeholder'=>'Ingresa número de telefono','readonly'])!!}
                </div>
            </div>
            <div class="row was-validated">
                
                <div class="col-xs-12 col-sm-6  form-group ">
                    {!!Form::label('auprivada','La Audiencia es Privada ?')!!}
                    <div class="row">
                        <div class="col-xs-12 col-lg-6">
                            <label><input type="radio" id="cbox1" value="1" name="audiencia_privada" > SI</label>
                            </div>
                            <div class="col-xs-12 col-lg-6">
                                <label><input type="radio" id="cbox2" value="0" name="audiencia_privada" > NO</label>
                            </div>
                    </div>
                    
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 form-group ">
                    {!!Form::label('detenido','AUDIENCIA CON DETENIDO(S) A CARGO DEL INPEC ?')!!}
                    <div class="row">
                        <div class="col-xs-12 col-lg-6">
                        <label><input type="radio" id="cbox3" value="1" name="detenido"  > SI</label>
                        </div>
                        <div class="col-xs-12 col-lg-6">
                            <label><input type="radio" id="cbox4" value="0" name="detenido" > NO</label>
                        </div>
                    </div>
                    
                </div>
            </div>                   
            </div>
          </div>
        <div class="modal-footer">
          <div class="container-fluid">
            <div class="row"> 
               
              <div class="col-xs-12 col-sm-6">                                          
                  <div class="container-buttons">
                      {!!link_to('#',$title = 'REGISTRAR DETENIDO', $attributes = ['class'=>'btn btn-primary  btn-block boton_guardar_detenido mt-1 p-1 pb-1','id'=>'boton_guardar_detenido'],$secure = null)!!}  
                  </div>
               {!!Form::close()!!}             
              </div>
              <div class="col-xs-12 col-sm-6">
                <a class="btn bg-elegant btn-warning btn-block " data-dismiss="modal">CANCELAR</a>                         
              </div>

            </div>
          </div>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->