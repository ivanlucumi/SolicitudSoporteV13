@extends('layouts.tecnicos')
<!--ponerle titulo a la paginga-->
@section('title', 'Solicitud Audiencia')
@section('cabecera', ' Edici&oacute;n de Solicitud ')

@section('content') 

{!!Form::model($solicitudAudiencia,['route'=>['tecnico.actualizar.audiencia.agendada',$solicitudAudiencia->id], 'method'=>'PUT'])!!}
			{{csrf_field()}}

@include('audiencias.tecnico.formularioAudiencia')

<hr>
<div class="row">
		<div class="col-xs-6">
			{!!Form::submit('Corregir Agendamiento',['class'=>'btn btn-primary btn-block'])!!}
		</div>
		<div class="col-xs-6">
		  <a href="{!! URL::previous()!!}" class="btn btn-danger  btn-block">Cancelar</a>
		</div>
						
</div>

{!!Form::close()!!}


@endsection