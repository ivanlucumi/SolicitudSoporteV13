<div>

    {!!Form::hidden('codigoDespacho',$solicitudAudiencia->codigoDespacho,['class'=>'form-control','shadow', 'autocomplete'=>"off"])!!}

</div>




<!-- inputs ocultos para el formulario   -->
<div >


        {!!Form::hidden('email',$solicitudAudiencia->email,['class'=>'form-control','shadow','required','placeholder'=>'Correo del despacho que solicita', 'autocomplete'=>"nope",'readonly'])!!}

    </div>

    <div >


        {!!Form::hidden('nombre_entidad',$solicitudAudiencia->nombre_entidad,['class'=>'form-control','shadow','required','placeholder'=>'Nombre', 'autocomplete'=>"off",'readonly'])!!}

    </div>

<!-- Fin de los inputs ocultos   -->

<div class="row ">

    <div class="col-xs-6 col-sm-4 form-group ">

        {!!Form::label('fechaA','Programar Fecha:')!!}

        {!!Form::date('fecha_prgramada',$solicitudAudiencia->fecha_prgramada,['class'=>'form-control','shadow','required', 'autocomplete'=>"off"])!!}

    </div>

    <div class="col-xs-6 col-sm-4 form-group ">

        {!!Form::label('horaI','Hora inicio:')!!}

        {!!Form::text('hora_inicio',$solicitudAudiencia->hora_inicio,['class'=>'form-control','shadow','required','id'=>'timepicker', 'autocomplete'=>"off",'placeholder'=>'Ingrese formato militar (24 horas)','required'])!!}

    </div>

    <div class="col-xs-6 col-sm-4  form-group ">

        {!!Form::label('horaF','Hora finalización:')!!}

        {!!Form::text('hora_fin',$solicitudAudiencia->hora_fin,['class'=>'form-control','shadow','required','id'=>'timepicker2','placeholder'=>'Ingrese formato militar (24 horas)', 'autocomplete'=>"off", 'required'])!!}

    </div>

    

</div>

<div class="row ">

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('ciudad','Ciudad origen de la audiencia:')!!}

        {!!Form::text('ciudad_destino',$solicitudAudiencia->ciudad_destino,['class'=>'form-control','shadow','required','placeholder'=>'Ingrese Ciudad de la Audiencia', 'autocomplete'=>"off",'readonly'])!!}

    </div>

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('entidadDest','Demandante:')!!}

        {!!Form::text('entidad_destino',$solicitudAudiencia->entidad_destino,['class'=>'form-control','shadow','required','placeholder'=>'Ingrese Demandante', 'autocomplete'=>"off"])!!}

    </div>

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('nRadicacion','Número de radicaci&oacute;n del proceso:')!!}

        {!!Form::number('numero_radicado_proceso',$solicitudAudiencia->numero_radicado_proceso,['class'=>'form-control','shadow','id'=>'nProceso',/*'onkeyup'=>"validarcantidad(this)",*/'min'=>'1','required','placeholder'=>'Ingrese número de radicado'])!!}

        <div id="cantidad"></div>

    </div>

</div>

<div class="row ">

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('decoindi','Declarante, Demandado o Indiciado?:')!!}

        {!!Form::text('declarante_indiciado',$solicitudAudiencia->declarante_indiciado,['class'=>'form-control','shadow','required','placeholder'=>'Ingrese nombre', 'autocomplete'=>"off"])!!}

    </div>

    <div class="col-xs-12 col-sm-6 col-md-4 form-group " style="display:none">

        {!!Form::label('direccion','Dirección:')!!}

        {!!Form::text('direccion',$solicitudAudiencia->direccion ,['class'=>'form-control','shadow','placeholder'=>'Ingrese la dirección', 'autocomplete'=>"off"])!!}

    </div>

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('telefono','Teléfono del solicitante:')!!}

        {!!Form::number('telefono',$solicitudAudiencia->telefono,['class'=>'form-control','shadow','required','min'=>'1','placeholder'=>'Ingrese número de tel&eacute;fono', 'autocomplete'=>"off"])!!}

    </div>

</div>

<div class="row ">

    

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('auprivada','La audiencia es reservada ?')!!}

        <div class="row">

            <div class="col-xs-12 col-lg-6">

                <label><input type="radio" id="cbox2" value="1" name="audiencia_privada" @if($solicitudAudiencia->audiencia_privada == '1')

                    <?php echo 'checked'; ?>

                @endif > SI</label>

                </div>

                <div class="col-xs-12 col-lg-6">

                    <label><input type="radio" id="cbox2" value="0" name="audiencia_privada" @if($solicitudAudiencia->audiencia_privada == '0')

                      <?php echo 'checked'; ?>

                    @endif > NO</label>

                </div>

        </div>

        

    </div>

    <div class="col-xs-12 col-sm-6 col-md-4 form-group ">

        {!!Form::label('detenido','Audiencia con detenidos(s) a cargo del inpec?')!!}

        <div class="row">

            <div class="col-xs-12 col-lg-6">

            <label><input type="radio" id="cbox1" value="1" name="detenido" onClick="condetenido()" @if($solicitudAudiencia->detenido == '1')

                <?php echo 'checked'; ?>

            @endif   > SI</label>

            </div>

            <div class="col-xs-12 col-lg-6">

                <label><input type="radio" id="cbox2" value="0" name="detenido" onClick="sindetenido()" @if($solicitudAudiencia->detenido == '0')

                  <?php echo 'checked'; ?>

                @endif > NO</label>

            </div>

        </div>

        

    </div>

</div>
<script>
     /*LIMITAR A SOLO 23 DIGITOS EL NUMERO DEL RADICADO DEL PROCESO*/
    var input = document.getElementById('nProceso');
    input.addEventListener('input', function() {
        if (this.value.length > 23)
            this.value = this.value.slice(0, 23);
    })


    //verificar los 23 digitos
    var input = document.getElementById('nProceso');
    input.addEventListener('input', function() {
        var maxLength = 23;
        if (this.value.length > 23) {
            document.getElementById("cantidad").innerHTML = '<strong> <span style="color: red;">' + this.value.length + ' de ' + maxLength + ' dígitos</span></strong>';
        }
        if (this.value.length === 23) {
            document.getElementById("cantidad").innerHTML = '<strong> <span style="color: green;">' + ' Ya esta completo los ' + maxLength + ' dígitos</span></strong>';
        } else {
            document.getElementById("cantidad").innerHTML = '<strong> <span style="color: red;">' + this.value.length + ' de ' + maxLength + ' dígitos</span></strong>';
        }
    })
 
function nombre(id){
        //console.log(id)
        div = document.getElementById(id);
            
        console.log('hola')

        } 
    
</script>