{!!Form::open(['route'=>$url, 'method'=>$method])!!}   

@include('audiencias.form.form')
<div class="row">
    <div class="col-xs-12 col-sm-4"></div>
    <div class="col-xs-12 col-sm-4" style="display:none" id="Detenido">
        {!! Form::submit('SIGUIENTE', ['class' => 'btn btn-success btn-block','style'=>'background-color: #007d6e; color: #fff;']) !!}
        
    </div>
    <div class="col-xs-12 col-sm-4" style="display:block" id="sinDetenido">
        {!! Form::submit('FINALIZAR', ['class' => 'btn btn-success btn-block','style'=>'background-color: #007d6e; color: #fff;']) !!}
        
    </div>
    
    <div class="col-xs-12 col-sm-4"></div>                
</div>   
{!! Form::close() !!} 