{!!Form::open(['route'=>$url, 'method'=>$method])!!}  

{{--  <!--formulario para verificar q se haya guardado correctamente-->  --}}


@include('audiencias.form.form')
<hr>

{!!Form::hidden('id',$solicitudAudiencia->id)!!}


<div id="detenido">
    <div class="container container-fluid">

    <div class="col-xs-6">
      {!!link_to('#',$title = 'AGREGAR DETENIDO QUE ASISTIRÁ', $attributes = ['class'=>'btn btn-primary boton_crear_detenido align-left','id'=>'boton_crear_detenido'],$secure = null)!!}

    </div>
    <br>

        <div class="row">

            
            <div class="col-md-9">

                <center><h2><strong> LISTA DE DETENIDOS QUE ASISTIRÁN</strong></h2></center>

                <table class="table text-center table-bordered" ><!--Creamos una tabla que mostrará todas las tareas-->

                        <thead style="background-color: #007d6e;">

                            <tr>

                                <th scope="col">NOMBRE</th>

                                <th scope="col">CIUDAD</th>

                                <th scope="col">NOMBRE ESTABLECIIENTO</th>

                                <th scope="col">Acciones</th>

                            </tr>

                        </thead>

                        @foreach($solicitudAudiencia->Detenidos as $detenido)

                            <tbody data-id="{!!$detenido->id!!}">

                            <tr>

                                <td>{{$detenido->nombre_interno}}</td>

                                <td>{{$detenido->ciudad}}</td>

                                <td>{{$detenido->nombre_estalecimiento}}</td> 

                                <td><button class="fa fa-trash btn-danger boton_delete_detenido" type="button"></button></td>

                            </tr>

                            </tbody>

                        @endforeach

                    </table>

            </div>

        </div>

    </div>

</div>

<hr>



<div class="row">

    <div class="col-xs-12 col-sm-4"></div>

    <div class="col-xs-12 col-sm-4">

        {!! Form::submit('FINALIZAR', ['class' => 'btn btn-success btn-block','style'=>'background-color: #007d6e; color: #fff;']) !!}

    </div>

    <div class="col-xs-12 col-sm-4"></div>                

</div>   

{!! Form::close() !!} 





{!!Form::open(['id'=>'form-delete-detenido','route'=>['virtual.audiencia.detenido.eliminar',':DETENIDO_ID'], 'method'=>'DELETE'])!!}

{!!Form::close()!!}