<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, minimal-ui">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="Mi Carnet">
    <link rel="manifest" href="{{ asset('manifest.json') }}">
    <link rel="apple-touch-icon" href="{{ asset('Logo/Siris.png') }}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{ asset('Logo/Siris.png') }}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('Logo/Siris.png') }}">
    <link rel="apple-touch-icon" sizes="167x167" href="{{ asset('Logo/Siris.png') }}">
    <link rel="icon" type="image/png" sizes="192x192" href="{{ asset('Logo/Siris.png') }}">
    <link rel="icon" type="image/png" sizes="512x512" href="{{ asset('Logo/Siris.png') }}">
    <link rel="shortcut icon" href="{{ asset('Logo/Siris.png') }}">
    <meta name="theme-color" content="#003f74">
    <title>Mi Carnet</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Mismos estilos base que carnet_resultado */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background: #f1f5f9;
        }

        .site-header {
            background: #003f74;
            padding: 12px 28px;
            display: flex;
            align-items: center;
            gap: 14px;
            box-shadow: 0 2px 10px rgba(0,0,0,.25);
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .site-header img {
            height: 42px;
            width: auto;
            filter: brightness(0) invert(1);
        }
        .site-header .ht strong {
            display: block;
            color: #fff;
            font-size: .92rem;
            font-weight: 700;
            line-height: 1.25;
        }
        .site-header .ht span {
            color: rgba(255,255,255,.78);
            font-size: .76rem;
        }

        .hero {
            background: linear-gradient(135deg, #003f74 0%, #00569d 55%, #0072bc 100%);
            padding: 48px 16px 90px;
            text-align: center;
            color: #fff;
            clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
        }
        .hero h1 { font-size: 1.6rem; font-weight: 800; margin-bottom: 6px; }
        .hero p { font-size: .92rem; opacity: .85; }

        .main-content {
            flex: 1;
            background: #f8fafc;
            margin-top: -64px;
            padding-bottom: 60px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        /* CARNET GLASSMORPHISM */
        .carnet {
            width: 350px;
            max-width: 90%;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            padding: 20px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1), inset 0 0 0 1px rgba(255,255,255,0.2);
            position: relative;
            transition: transform .3s ease, box-shadow .3s ease;
            user-select: none;
            cursor: pointer;
            margin-bottom: 30px;
            overflow: hidden;
            display: none; /* Oculto por defecto hasta cargar js */
        }
        .carnet::before {
            content: "";
            position: absolute;
            top: -50px; left: -50px;
            width: 150px; height: 150px;
            background: rgba(0, 123, 255, 0.1);
            filter: blur(40px);
            border-radius: 50%;
            z-index: 0;
            pointer-events: none;
        }
        
        .watermark {
            position: absolute; inset: 0;
            background-image: url('https://www.disajcali.gov.co/img/logoLargo.png');
            background-repeat: repeat; background-size: 30px;
            opacity: .05; pointer-events: none; border-radius: 20px;
            animation: wm-move 20s linear infinite;
        }
        @keyframes wm-move { 0% { background-position: 0 0; } 100% { background-position: 100px 100px; } }

        .hologram {
            position: absolute; top: 15px; right: 15px; width: 40px; height: 40px;
            background: radial-gradient(circle, rgba(0,123,255,.3), transparent);
            border-radius: 50%; opacity: .6;
            animation: holo 2.5s ease-in-out infinite;
        }
        @keyframes holo { 0%, 100% { transform: scale(1); opacity: .4; } 50% { transform: scale(1.3); opacity: .7; } }

        .carnet-logo { width: 80%; margin-bottom: 20px; position: relative; z-index: 1; }
        .foto-container { position: relative; display: inline-block; margin-bottom: 15px; z-index: 1; }
        .foto { width: 130px; height: 130px; border-radius: 50%; object-fit: cover; border: 5px solid rgba(255,255,255,0.8); box-shadow: 0 4px 15px rgba(0,0,0,.15); background:#fff; margin: 0 auto;}
        .avatar-initials { width: 130px; height: 130px; border-radius: 50%; background: #003f74; color: white; display: flex; align-items: center; justify-content: center; font-size: 50px; font-weight: bold; border: 5px solid rgba(255, 255, 255, 0.8); box-shadow: 0 4px 15px rgba(0,0,0,.15); margin: 0 auto; }
        .status-badge {
            position: absolute; bottom: 5px; right: 5px; background: #16a34a; color: white;
            width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            border: 3px solid #fff; font-size: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .emp-name { font-size: 1.15rem; font-weight: 800; color: #1a1a2e; margin: 10px 0 6px; position: relative; z-index: 1; line-height: 1.2; }
        .dato { font-size: .92rem; color: #334155; margin: 4px 0; position: relative; z-index: 1; }
        .dato strong { color: #0f172a; font-weight: 700; }
        .barcode { display: flex; justify-content: center; margin-top: 20px; position: relative; z-index: 1; background: white; padding: 5px; border-radius: 8px; width: 170px; margin-left: auto; margin-right: auto; }
        .barcode img { width: 160px; height: 50px; }
        .footer-carnet { background: linear-gradient(135deg, #003f74 0%, #0072bc 100%); color: #fff; padding: 10px; font-weight: 700; border-radius: 12px; margin-top: 15px; font-size: 11px; line-height: 1.4; position: relative; z-index: 1; }

        .acciones { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; margin-top: 10px; padding: 0 15px; }
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 12px 20px; border-radius: 12px; font-size: .9rem; font-weight: 700; cursor: pointer; text-decoration: none; border: none; transition: all .2s; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .btn-danger { background: #dc2626; color: white; }
        .btn-refresh { background: #3b82f6; color: white; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 6px 12px rgba(0,0,0,0.15); }

        .empty-state {
            display: none;
            text-align: center;
            padding: 40px 20px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            max-width: 90%;
            margin-top: 20px;
        }
        .empty-state i { font-size: 4rem; color: #94a3b8; margin-bottom: 15px; }
        .empty-state h3 { font-size: 1.25rem; color: #334155; margin-bottom: 10px; }
        .empty-state p { color: #64748b; margin-bottom: 20px; font-size: 0.95rem; }

        /* --- Modals --- */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); backdrop-filter: blur(4px); align-items: center; justify-content: center; }
        .modal-content { background: white; padding: 30px; border-radius: 20px; width: 90%; max-width: 350px; text-align: center; animation: popIn 0.3s cubic-bezier(0.18, 0.89, 0.32, 1.28); }
        @keyframes popIn { 0% { transform: scale(0.8); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
        .loading-state { color: #003f74; }
        .status-ok { color: #16a34a; }
        .status-error { color: #dc2626; }
        .result-state h2 { margin: 10px 0; font-size: 1.5em; }
        .btn-close { background: #003f74; color: white; border: none; padding: 12px 25px; border-radius: 25px; font-weight: 600; width: 100%; cursor: pointer; }
    </style>
</head>
<body oncontextmenu="return false;">

    <header class="site-header">
        <img src="https://www.disajcali.gov.co/img/logoLargo.png" alt="DISAJ">
        <div class="ht">
            <strong>Dirección Seccional de Administración Judicial</strong>
            <span>Cali – Valle del Cauca</span>
        </div>
    </header>

    <div class="hero">
        <h1>Mi Carnet Digital</h1>
        <p>"Fortaleciendo la justicia, promoviendo el bienestar de todos".</p>
    </div>

    <main class="main-content">
        
        <div class="empty-state" id="emptyState">
            <i class="fa-solid fa-id-card-clip"></i>
            <h3>No tienes un carnet guardado</h3>
            <p>Por favor, realiza una consulta y guárdalo en tu dispositivo.</p>
            <a href="{{ route('carnet.consulta') }}" class="btn btn-refresh">Ir a Consultar2</a>
        </div>

        <div class="carnet" id="carnetRender" onclick="validateIdentityServer()" title="Toca para verificar estado actual">
            <div class="watermark"></div>
            <div class="hologram"></div>
            <img class="carnet-logo" src="https://www.disajcali.gov.co/img/logoLargo.png" alt="Logo">

            <div class="foto-container">
                <img class="foto" id="c_foto" src="" alt="Foto">
                <span class="status-badge" id="c_badge"><i class="fa-solid fa-check"></i></span>
            </div>

            <h2 class="emp-name" id="c_nombre"></h2>
            <p class="dato"><strong>Cédula:</strong> <span id="c_cedula"></span></p>
            <p class="dato"><strong>Cargo:</strong> <span id="c_cargo"></span></p>
            <p class="dato" id="c_obs_container" style="display:none;"><strong>Obs:</strong> <span id="c_obs"></span></p>

            <div class="barcode">
                <img id="c_barcode" src="" alt="Código de Barras">
            </div>

            <div class="footer-carnet">
                DIRECCIÓN SECCIONAL DE ADMINISTRACIÓN JUDICIAL<br>CALI, VALLE DEL CAUCA
            </div>
        </div>

        <div class="acciones" id="accionesContainer" style="display:none;">
            <button class="btn btn-refresh" onclick="validateIdentityServer()" id="btnValidar">
                <i class="fa-solid fa-rotate"></i>
            </button>
            <button class="btn btn-danger" onclick="deleteCarnet()">
                <i class="fa-solid fa-trash-can"></i>
            </button>
        </div>
    </main>

    <!-- Modal de Validación PWA -->
    <div id="validationModal" class="modal">
        <div class="modal-content" id="modalContent">
            <div class="loading-state" id="loadingState">
                <img id="modalSpinPhoto" src="" class="fa-spin" style="width: 90px; height: 90px; border-radius: 50%; object-fit: cover; border: 4px solid #059669; display: none; margin: 0 auto; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
                <div id="modalSpinInitials" class="fa-spin" style="width: 90px; height: 90px; border-radius: 50%; background: #003f74; color: white; display: none; align-items: center; justify-content: center; font-size: 36px; font-weight: bold; border: 4px solid #00569d; margin: 0 auto; box-shadow: 0 4px 10px rgba(0,0,0,0.1);"></div>
                <i class="fa-solid fa-circle-notch fa-spin status-ok" id="loadingIconFallback" style="font-size: 50px;"></i>
                <h3 style="margin-top:20px;">VERIFICANDO FUNCIONARIO...</h3>
            </div>
            
            <div id="resultState" style="display:none;">
                <i id="resultIcon" class="fa-solid fa-circle-check" style="font-size: 60px; margin-bottom: 15px;"></i>
                <h2 id="resultTitle">Resultado</h2>
                <p id="resultMessage" style="color: #475569; margin-bottom: 20px;"></p>
                <button class="btn-close" id="btnCloseModal" onclick="closeModal()">Entendido</button>
            </div>
        </div>
    </div>

    <script>
        // Registrar Service Worker para PWA
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register("{{ asset('sw.js') }}").then(reg => {
                    console.log('SW Registrado en PWA', reg);
                });
            });
        }

        let savedData = null;

        document.addEventListener('DOMContentLoaded', () => {
            loadCarnetFromLocal();
        });

        function loadCarnetFromLocal() {
            const urlParams = new URLSearchParams(window.location.search);
            const token = urlParams.get('token');

            let dataStr = localStorage.getItem('carnet_pwa_data');
            
            if (!dataStr && token) {
                // Modo iOS: Al abrir un PWA en la pantalla de inicio, puede perder el LocalStorage original de Safari.
                // Descargamos los datos nuevamente validándolos por el token.
                document.getElementById('emptyState').style.display = 'none';
                
                fetch(`/api/carnet/token/${token}`)
                    .then(r => {
                        if (!r.ok) throw new Error("Carnet no encontrado");
                        return r.json();
                    })
                    .then(data => {
                        savedData = data;
                        localStorage.setItem('carnet_pwa_data', JSON.stringify(data));
                        
                        // Limpiar la URL para evitar que quede expuesto el parametro al usuario
                        window.history.replaceState({}, document.title, window.location.pathname);
                        
                        renderCarnet(savedData);
                        validateIdentityServer(true);
                    })
                    .catch(e => {
                        alert("No pudimos sincronizar el carnet en tu dispositivo. Por favor asegúrate de tener internet al abrirlo por primera vez.");
                        window.location.href = "{{ route('carnet.consulta') }}";
                    });
                return;
            }

            if (dataStr) {
                savedData = JSON.parse(dataStr);
                renderCarnet(savedData);
                // Validar de fondo siempre que inicie la app para evitar inactivos
                validateIdentityServer(true); 
            } else {
                // Si no hay datos, redirigimos a la consulta
                window.location.href = "{{ route('carnet.consulta') }}";
            }
        }

        function renderCarnet(data) {
            document.getElementById('emptyState').style.display = 'none';
            document.getElementById('carnetRender').style.display = 'block';
            document.getElementById('accionesContainer').style.display = 'flex';

            const fotoEl = document.getElementById('c_foto');
            let imgSrc = data.foto;
            // Si guarda solo el nombre del archivo (ej. 123.jpg), asegurar la ruta correcta:
            if (imgSrc && !imgSrc.startsWith('http') && !imgSrc.startsWith('/') && !imgSrc.includes('img/carnet')) {
                imgSrc = '/img/carnet/' + imgSrc;
            }
            fotoEl.src = imgSrc;
            fotoEl.onerror = function() {
                this.style.display = 'none';
                if (!document.getElementById('c_initials')) {
                    const initialsDiv = document.createElement('div');
                    initialsDiv.id = 'c_initials';
                    initialsDiv.className = 'avatar-initials';
                    initialsDiv.innerText = data.iniciales || 'RJ';
                    this.parentElement.insertBefore(initialsDiv, this.parentElement.firstChild);
                }
            };

            document.getElementById('c_nombre').innerText = data.nombre;
            document.getElementById('c_cedula').innerText = data.cedula;
            document.getElementById('c_cargo').innerText = data.cargo;
            
            if (data.observacion) {
                document.getElementById('c_obs_container').style.display = 'block';
                document.getElementById('c_obs').innerText = data.observacion;
            }

            document.getElementById('c_barcode').src = `https://barcode.tec-it.com/barcode.ashx?data=${data.cedula}&code=Code128`;

            const badge = document.getElementById('c_badge');
            if (data.esActivo) {
                badge.style.background = '#16a34a';
                badge.innerHTML = '<i class="fa-solid fa-check"></i>';
            } else {
                badge.style.background = '#dc2626';
                badge.innerHTML = '<i class="fa-solid fa-xmark"></i>';
            }
        }

        function deleteCarnet() {
            if(confirm("¿Estás seguro de que deseas eliminar tu carnet digital de este dispositivo?")) {
                if (savedData && savedData.cedula) {
                    const btn = document.querySelector('.btn-danger');
                    if (btn) {
                        btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Eliminando...';
                        btn.disabled = true;
                    }

                    fetch('/api/carnet/revocar', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({ cedula: savedData.cedula })
                    })
                    .finally(() => {
                        localStorage.removeItem('carnet_pwa_data');
                        window.location.reload();
                    });
                } else {
                    localStorage.removeItem('carnet_pwa_data');
                    window.location.reload();
                }
            }
        }

        function closeModal() {
            document.getElementById('validationModal').style.display = 'none';
        }

        // Validación estricta con servidor
        function validateIdentityServer(silentMode = false) {
            if (!savedData) return;
            
            const modal = document.getElementById('validationModal');
            const loading = document.getElementById('loadingState');
            const result = document.getElementById('resultState');
            
            const btn = document.getElementById('btnValidar');
            if(btn && !silentMode) {
                btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Validando...';
                btn.disabled = true;
            }

            if (!silentMode) {
                // Configurar foto girando
                const imgFoto = document.getElementById('c_foto');
                const cssInitials = document.getElementById('c_initials');
                
                if (imgFoto && window.getComputedStyle(imgFoto).display !== 'none') {
                    document.getElementById('modalSpinPhoto').src = imgFoto.src;
                    document.getElementById('modalSpinPhoto').style.display = 'block';
                    document.getElementById('modalSpinInitials').style.display = 'none';
                    document.getElementById('loadingIconFallback').style.display = 'none';
                } else if (cssInitials) {
                    document.getElementById('modalSpinInitials').innerText = cssInitials.innerText;
                    document.getElementById('modalSpinInitials').style.display = 'flex';
                    document.getElementById('modalSpinPhoto').style.display = 'none';
                    document.getElementById('loadingIconFallback').style.display = 'none';
                }

                modal.style.display = 'flex';
                loading.style.display = 'block';
                result.style.display = 'none';
            }

            fetch(`/api/carnet/validar?cedula=${savedData.cedula}`)
                .then(response => response.json())
                .then(data => {
                    if (!silentMode) {
                        loading.style.display = 'none';
                        result.style.display = 'block';
                    }

                    if(btn && !silentMode) {
                        btn.innerHTML = '<i class="fa-solid fa-rotate"></i> Validar Estado';
                        btn.disabled = false;
                    }

                    if (data.activo === false || data.status === 'error') {
                        localStorage.removeItem('carnet_pwa_data');
                        if (!silentMode) {
                            document.getElementById('resultIcon').className = 'fa-solid fa-circle-xmark status-error';
                            document.getElementById('resultTitle').innerText = 'Acceso Denegado';
                            document.getElementById('resultTitle').style.color = '#dc2626';
                            document.getElementById('resultMessage').innerText = data.message || 'Este carnet está inactivo o vencido. Ha sido eliminado del dispositivo.';
                            document.getElementById('btnCloseModal').onclick = function() { window.location.reload(); };
                        } else {
                           alert("⚠️ SESIÓN REVOCADA:\nTu carnet ha sido desactivado o no está vigente. Se eliminará del dispositivo por seguridad.");
                            window.location.reload();
                        }
                    } else if (!silentMode) {
                        if (data.status === 'warning') {
                            document.getElementById('resultIcon').className = 'fa-solid fa-triangle-exclamation status-error';
                            document.getElementById('resultTitle').innerText = '¡Alerta de Ingreso!';
                            document.getElementById('resultTitle').style.color = '#f59e0b';
                            document.getElementById('resultMessage').innerText = data.message;
                            if (data.action === 'purge_required') {
                                localStorage.removeItem('carnet_pwa_data');
                                document.getElementById('btnCloseModal').onclick = function() { window.location.reload(); };
                            }
                        } else {
                            document.getElementById('resultIcon').className = 'fa-solid fa-circle-check status-ok';
                            document.getElementById('resultTitle').innerText = 'Validación Exitosa';
                            document.getElementById('resultTitle').style.color = '#16a34a';
                            document.getElementById('resultMessage').innerText = data.message || 'El carnet se encuentra Activo y Vigente.';
                        }
                    }
                })
                .catch(error => {
                    if (!silentMode) {
                        loading.style.display = 'none';
                        result.style.display = 'block';
                        document.getElementById('resultIcon').className = 'fa-solid fa-wifi';
                        document.getElementById('resultIcon').style.color = '#94a3b8';
                        document.getElementById('resultTitle').innerText = 'Modo Sin Conexión';
                        document.getElementById('resultTitle').style.color = '#475569';
                        document.getElementById('resultMessage').innerText = "No tienes internet.\nMostrando último estado seguro guardado.";
                    }
                    if(btn && !silentMode) {
                        btn.innerHTML = '<i class="fa-solid fa-rotate"></i> Validar Estado';
                        btn.disabled = false;
                    }
                });
        }

        // --- PROTECCIÓN DE SEGURIDAD ---
        document.addEventListener('keydown', function(e) {
            // F12
            if (e.keyCode === 123) {
                e.preventDefault();
                return false;
            }
            // Ctrl+Shift+I / J / C
            if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67)) {
                e.preventDefault();
                return false;
            }
            // Ctrl+U (Ver código fuente)
            if (e.ctrlKey && e.keyCode === 85) {
                e.preventDefault();
                return false;
            }
            // Print Screen (Imprimir Pantalla en PC)
            if (e.keyCode === 44) {
                e.preventDefault();
                navigator.clipboard.writeText('');
                alert("La captura de pantalla está deshabilitada por seguridad.");
                return false;
            }
        });

        // Evitar Copiar
        document.addEventListener('copy', function(e) {
            e.preventDefault();
            return false;
        });

        // Ocultar contenido al perder el foco (mitigar capturas en segundo plano)
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                document.body.style.opacity = '0';
            } else {
                document.body.style.opacity = '1';
            }
        });
    </script>
</body>
</html>
